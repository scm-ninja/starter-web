# Starter Web Repo

This repository is for showing how Git and GitHub work

## Purpose

Sample website with plenty of files for demos